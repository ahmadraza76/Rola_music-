# RolaVibe Bot

A high-quality music streaming bot for Telegram groups.

## Features
- Play music from YouTube and Spotify.
- Queue management.
- Admin and owner commands.

## Setup
1. Clone the repository.
2. Install dependencies using `pip install -r requirements.txt`.
3. Configure `config.py` with your API keys.
4. Run the bot using `python3 main.py`.