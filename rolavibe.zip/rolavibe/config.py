API_ID = 6701155507  # Aapka Telegram account ka API ID
API_HASH = "ee0b6a29d4918aa6dabeb181d2c15a36"  # Aapka Telegram account ka API Hash
BOT_TOKEN = "7947838073:AAFoW-26Q0ulpIBgkafeE7zz91uqQayysn0"  # Aapke bot ka token
OWNER_ID = 5620922625  # Aapka personal Telegram user ID (owner ID)
SPOTIFY_CLIENT_ID = "07e0249e87044dd69b20bfa841ff2d24"  # Spotify Client ID
SPOTIFY_CLIENT_SECRET = "d38e214ff06e43a386fc20d4fa02ab88"  # Spotify Client Secret